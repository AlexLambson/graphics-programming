#pragma once
/*#include "Structs.h"
#include <glut.h>
class Rat
{
public:
	Rat();
	Rat(double cellX, double cellY);
	void Draw();
	Position GetIndex();
	bool CanMove(PositionD position, CellWalls walls);
	//move the rat this many points
	void Move(Key::Type key, CellWalls walls);
private:
	PositionD mPosition;
	double mRotation;
	//glpushmatrix
	//gltranslated(x, y, 0)
	//glrotated(mrotation, 0, 0, 1)
	//draw rat at origin
	double mSize;
};
*/